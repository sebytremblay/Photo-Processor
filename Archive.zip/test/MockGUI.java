import java.awt.image.BufferedImage;

import controller.Features;
import view.ImageProcessorGUI;

public class MockGUI implements ImageProcessorGUI {
  @Override
  public void setImage(BufferedImage img) {

  }

  @Override
  public void setHistogram(int[][] histogram) {

  }

  @Override
  public void refresh() {

  }

  @Override
  public void renderMessage(String message) {

  }

  @Override
  public void acceptsFeaturesObject(Features feature) {

  }
}
