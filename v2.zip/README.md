# cs3500
Repository for Dilan and I's cs3500 homeworks. 

//TODO ADD TO THIS
load 


This website is where we obtained the image of the flowers
https://www.usna.edu/Users/cs/choi/ic210/project/p01/index.html